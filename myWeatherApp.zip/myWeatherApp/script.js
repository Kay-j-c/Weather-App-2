document.addEventListener("DOMContentLoaded", function() {
    fetchWeatherData();
});

function fetchWeatherData() {
    const apiURL = "https://api.weather.gov/gridpoints/MTR/84,105/forecast";

    fetch(apiURL)
        .then(response => {
            if (!response.ok) {
                throw new Error("Failed to fetch weather data");
            }
            return response.json();
        })
        .then(data => {
            displayCurrentWeather(data.properties.periods[0]);
            displayForecast(data.properties.periods.slice(1, 4));
        })
        .catch(error => {
            console.error("Error fetching weather data:", error);
        });
}

function displayCurrentWeather(currentWeather) {
    const currentWeatherDiv = document.getElementById("currentWeather");
    const weatherCard = createWeatherCard(currentWeather);
    currentWeatherDiv.appendChild(weatherCard);
}

function displayForecast(forecastData) {
    const forecastDiv = document.getElementById("forecast");
    forecastData.forEach(forecast => {
        const forecastCard = createWeatherCard(forecast);
        forecastDiv.appendChild(forecastCard);
    });
}

function createWeatherCard(weather) {
    const weatherCard = document.createElement("div");
    weatherCard.classList.add("weather-card");
    weatherCard.innerHTML = `
        <h2>${weather.name}</h2>
        <p>${weather.detailedForecast}</p>
    `;
    return weatherCard;
}

